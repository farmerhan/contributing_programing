/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ltpt_tranvanvu_1951064115_lab3;

import java.util.*;
/**
 *
 * @author tranvanvu
 */
class Consumer implements Runnable {
    BoundedBuffer b = null;
    public Consumer(BoundedBuffer initb) {
        b = initb;
        new Thread(this).start();
    }
    public static boolean checkPrimeNumber(int number) {
        if(number <= 1) {
            return false;
        }
        for(int i=2;i<number;i++) {
            if(number%i == 0) {
                return false;
            }
        }
        return true;
    }
    public void run() {
        int item;
        while (true) {
            item = b.fetch();
            boolean isPrimeNumber = checkPrimeNumber(item);
            if(isPrimeNumber) {
                System.out.println(item + " is prime number"); 
            } else {
                System.out.println(item + " is not prime number"); 
            }
            Util.mySleep(1000);
        }
    }
}

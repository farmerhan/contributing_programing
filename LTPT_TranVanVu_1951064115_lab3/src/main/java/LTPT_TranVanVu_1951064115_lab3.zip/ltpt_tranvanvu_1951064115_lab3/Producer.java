/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ltpt_tranvanvu_1951064115_lab3;

import java.util.*;
/**
 *
 * @author tranvanvu
 */
class Producer implements Runnable {
    BoundedBuffer b = null;
    static int min = 10;
    static int max = 200;
    public Producer(BoundedBuffer initb) {
        b = initb;
        new Thread(this).start();
    }
    public void run() {
        int item;
        Random r = new Random();
        while (true) {
            item = r.ints(min, max)
                    .findFirst()
                    .getAsInt();
            System.out.println("produced item " + item);
            b.deposit(item);
            Util.mySleep(1000);
        }
    }
}


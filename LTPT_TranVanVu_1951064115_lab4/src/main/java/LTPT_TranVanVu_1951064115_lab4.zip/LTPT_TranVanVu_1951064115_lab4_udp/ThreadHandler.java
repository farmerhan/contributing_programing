/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LTPT_TranVanVu_1951064115_lab4_udp;
import java.util.*;
/**
 *
 * @author tranvanvu
 */
public class ThreadHandler extends Thread {
    private String integersString = null;
    private ArrayList<Integer> oddIntegers = null;    
    private ArrayList<Integer> evenIntegers = null;
    private String resultString;

    public ThreadHandler(String integersString) {
        this.integersString = integersString;
        this.oddIntegers = new ArrayList<Integer>();
        this.evenIntegers = new ArrayList<Integer>();
        this.resultString = "";
    }
    
    public void splitStringIntoOddAndEventIntegers() {
        String[] items = this.integersString.split("\\s");
        
        for(String item : items) {
            int number = Integer.parseInt(item);
            if(number%2==0) {
                evenIntegers.add(number);
                continue;
            }
            oddIntegers.add(number);
        }
    }
    
    public String getSortInterleavingListString() {
        Collections.sort(this.evenIntegers);
        Collections.sort(this.oddIntegers);        
        
        int lengthEvenIntegers = this.evenIntegers.size();
        int lengthOddIntegers = this.oddIntegers.size();
        
        int counter1 = 1;
        int counter2 = 0;
        
        String resultString = Integer.toString(this.evenIntegers.get(0));
        String separate = " ";
        
        while(counter1 < lengthEvenIntegers || counter2 < lengthOddIntegers) {
            if(counter2 < lengthOddIntegers) {
                resultString += separate + this.oddIntegers.get(counter2);
                counter2++;
            }
            
            if(counter1 < lengthEvenIntegers) {
                resultString += separate + this.evenIntegers.get(counter1);
                counter1++;
            }
        }
        
        return resultString;
    }
    
    public void run() {
        this.splitStringIntoOddAndEventIntegers();
        this.resultString = this.getSortInterleavingListString();
    }
    
    public String getResultString() {
        return this.resultString;
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LTPT_TranVanVu_1951064115_lab4_udp;

/**
 *
 * @author tranvanvu
 */
import java.net.*;
import java.io.*;
public class DatagramServer {
    public static void main(String[] args) {
        DatagramPacket datapacket, returnpacket;
        int port = 2018;
        int len = 1024;
        try {
            DatagramSocket datasocket = new DatagramSocket(port);
            byte[] buf = new byte[len];
            datapacket = new DatagramPacket(buf, buf.length);
            while (true) {
                try {
                    Util.mySleep(1000);
                    // Receive
                    datasocket.receive(datapacket);
                    String receivedStr = new String(datapacket.getData(), 0, datapacket.getLength());
                    
                    // Handle
                    ThreadHandler thandler = new ThreadHandler(receivedStr);
                    thandler.start();
                    try {
                        thandler.join();                        
                    } catch(Exception e) {
                        System.out.print(e.getMessage());
                    }
                    
                    // Send
                    String responseData = thandler.getResultString();
                    returnpacket = new DatagramPacket(
                            responseData.getBytes(), 
                            datapacket.getLength(), 
                            datapacket.getAddress(), 
                            datapacket.getPort());
                    datasocket.send(returnpacket);
                } catch (IOException e) {
                    System.err.println(e);
                }
            }
        } catch (SocketException se) {
            System.err.println(se);
        }
    }
}

